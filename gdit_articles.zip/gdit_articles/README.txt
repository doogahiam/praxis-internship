Each of the PDF files in this directory represent "webpage-to-pdf" conversions of articles from www.gdit.com.

The PDF files were created using the wkhtmltopdf tool using the following arguments: --page-size Letter --no-pdf-compression --no-background

In addition to the PDF files, you will find:
  - titles.txt: This file lists the titles of each of the articles (in some cases, the article title did not make it into the PDF conversion). The titles are listed in the same order as the PDF files are numbered (the first line corresponds to the 0.pdf file, second line corresponds to the 1.pdf file, etc.).
  - urls.txt: This file lists the original URLs used to extract each article. The URLs are listed in the same order as the PDF files are numbered (the first line corresponds to the 0.pdf file, second line corresponds to the 1.pdf file, etc.).
  
